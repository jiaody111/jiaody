//index.js
Page({
  data: {
  },

  onLoad: function() {
  },
  navToPre(){
    wx.navigateTo({
      url: '/pages/experience/datapre/datapre',
    })
  }
})
